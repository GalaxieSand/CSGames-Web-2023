# Français 

## Description

La rébellion a besoin de vous! Nous devons travailler ensemble afin de préserver nos connaissances. Vous avez été choisi par l'Undergrad Society afin de compléter un logiciel critique. Une interface utilisateur va devoir être créée afin de consumer les services d'une infrastructure qui a été abandonnée avant d'être terminée.

## Compétences requises

JWT, OpenAPI and votre langage multi-plateforme préféré

## Quoi apporter

Votre ordinateur portable

# Anglais 

## Description

The rebellion needs you! We must work together in order the preserve our most advanced technical knowledge. In fact, you've been chosen to help the Undergrad Society to finish a critical piece of software. A front-end will need to be created in order to consume services from a back-end that was left unfinished.

## Skills

JWT, OpenAPI and your preferred crossplatform langage

## What to bring

Your own laptop

# Autres informations

## Nombre de participants: 2

## Durée : 3 heures

## Weight/Poids: {TBA}
TBA - Le CO va décider du poids en temps et lieu. 