`Web`
----------------

Directeur de compétition: `Jordan Guérin`

Description préliminaire: `Les programmeurs doivent bâtir une nouvelle plateforme anonyme afin de pouvoir partager du code sans pouvoir être retracé. Certaine partie du code serveur ont déja été implémenté. Le serveur d'identité qui gère la connexion des utilisateurs, ainsi que le service de dépôt de code. Pour gérer les accès aux services, un JSON Web Token sera utilisé.`

[Énoncé FR](src/webdocs/static/enonce.md)
[Énoncé EN](src/webdocs/static/tasks.md)
