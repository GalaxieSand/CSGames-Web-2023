

class RepositorySummary:
    def __init__(self, id=0, name="", description="", license=""):
        self.id = id
        self.name = name
        self.description = description
        self.license = license