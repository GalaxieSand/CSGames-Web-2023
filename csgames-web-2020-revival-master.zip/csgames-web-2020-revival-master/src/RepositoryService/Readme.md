#### Repositories Service

Service listant les dépôts de code disponible sur le serveur. 
Offre aussi la possibilité d'accèder aux dépôts, pour afficher un fichier, lister les commits, voir les arbres et consulter les autres informations sur les dépôts.

