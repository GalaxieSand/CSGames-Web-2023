##### Services fournis pour la compétition

`Ce répertoire contiendra les services qui seront founis aux participants lors de la compétition.`

 * Serveur d'identité : Émission de JWT et création d'utilisateur
 * Service de dépôt : Contient les informations à propos des dépôts de code qui pourront être consulté à partir du site web.
 * webdocs : Pour consulter l'énoncé et les specs pour le Snippets Service

#### To Do

 [ ] - Traduction anglais
 [ ] - Soumission
