#### Snippet Service

Implémentation d'un snippet service basé sur le YAML qui sera donné aux participants. Le but de cette implémentation est de bâtir des tests automatisés pour faciliter la correction des tâches back-end des équipes.