#### GitRepoAnonmyizer

  Récupères des répos à partir de GitHUb, anonymize les commits avec des nouveaux emails et authors générés.
  Création automatique des utilisateurs grâce aux appels à Id Server.
  

